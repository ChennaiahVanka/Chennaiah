import { Component, OnInit } from '@angular/core';
import { ShoeService } from '../shoe.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-userorderdetails',
  templateUrl: './userorderdetails.component.html',
  styleUrls: ['./userorderdetails.component.css']
})
export class UserorderdetailsComponent implements OnInit {
  orders:any=""
  constructor(private ss:ShoeService,private router:Router) { }
  srh = localStorage.getItem("userid");

  ngOnInit(): void {
    this.ss.getuserorderdetails(this.srh).subscribe((fanta)=>{
      console.log(fanta)
      this.orders=fanta;

    })

  }
  Back(){
    this.router.navigate(['/products'])
  }

}
