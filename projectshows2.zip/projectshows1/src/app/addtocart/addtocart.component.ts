import { Component, OnInit } from '@angular/core';
// import { ShoeService } from '../shoe.service';
import { ActivatedRoute, Router } from '@angular/router';
@Component({
  selector: 'app-addtocart',
  templateUrl: './addtocart.component.html',
  styleUrls: ['./addtocart.component.css']
})
export class AddtocartComponent implements OnInit {

  constructor(private router:Router,private route:ActivatedRoute) { }
  // private ss:ShoeService,
  productType:any=""
  quantity:number=1
  customerName=""
  phoneNumber=""
  address=""
  userid=""

  ngOnInit(): void {
    this.route.queryParams.subscribe(params=>{
      this.productType=params['productName'];
    })
  }
  product(){
    this.router.navigate(['/products']);
  }
  id=localStorage.getItem("userid");
  onOrder(){
 
    let body={
      productType:this.productType,
      quantity:this.quantity,
      customerName:this.customerName,
      phoneNumber:this.phoneNumber,
      address:this.address,
      userid:this.id
    }
    this.ss.postorder(body).subscribe((data=>{
      alert("Order placed successfully")
    }))
    this.clearForm();
  }
  clearForm(){
    this.productType="",
    this.quantity=1,
    this.customerName="",
    this.phoneNumber="",
    this.address=""
  }


}
