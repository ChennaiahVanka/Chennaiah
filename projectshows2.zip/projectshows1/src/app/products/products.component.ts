import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
// import { ShoeService } from '../shoe.service';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Route } from '@angular/router';
@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {

  constructor( private router:Router,private route:Router) { }
  // private ss:ShoeService,
 
  data:any=null;
  fan:any;
  ID=localStorage.getItem("userid");
  quantity:any="1";
  productType:any;
  price:any;
  imageUrl:any;
  size:any="";

  
  ngOnInit(): void {
    console.log(localStorage.getItem('token'));
    this.ss.getproduct()
    .subscribe((data:any)=>{

      this.data = data
      console.log(data)
     
      
    })
  }
  onlogout(){
    localStorage.removeItem("token");
    localStorage.removeItem("userid")
    this.router.navigate(['/userlogin']);

  }
  onQuantityChange(product: any, quantity: number) {
    if (product.quantity==undefined) {
      product.quantity = 1; 
    } else {
      product.quantity = quantity;
    }
    }
    onSizeChange(product: any, size: number) {
      if (product.size==undefined) {
        alert("Size required")
      } else {
        product.size = size;
       
      }
  }
  carts(product:any){
    debugger
    if(product.productType){
        this.fan=product.productType;
    }
    console.log(product.quantity)
    let body={
     
      productType:product.productType,
      price:product.price*product.quantity,
      quantity:product.quantity,
      imageUrl:product.imageurl,
      userid:this.ID,
      size:product.size
    }

/*    this.ss.additemtocart(body).subscribe((data)=>{
      console.log(body);
      console.log(data);
      if(data=="not done"){
        alert("quantity");
      }
      else{
        alert("product added to cart");
      }
    })*/
    this.ss.additemtocart(body).subscribe(
      (data) => {
        console.log(body);
        console.log(data);
        if (data != "not done") {
          alert("added to cart");
        }
      },
      (error) => {
        console.error(error);
        alert("There was an error adding the product to the cart.");
        this.route.navigate(['/cartitems'])
      }
    );
  }
    goto(){
      this.router.navigate(['/cartitems'])
    }
    onclick(){
      this.router.navigate(['/userorderdetails'])
    }
    onhome(){
      this.router.navigate(['/home'])
    }
   
   

}

