import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
// import { ShoeService } from '../shoe.service';

@Component({
  selector: 'app-adminlogin',
  templateUrl: './adminlogin.component.html',
  styleUrls: ['./adminlogin.component.css']
})
export class AdminloginComponent implements OnInit {

  constructor(private router:Router ) { }
  // private ss:ShoeService,
  userName=""
  password=""

  ngOnInit(): void {
    if(localStorage.getItem('adtoken')!=="invalid"){
      
      this.router.navigateByUrl('/updateproducts');
    }
    else (localStorage.getItem('adtoken')!=null)
    {
      this.router.navigateByUrl('/adminlogin');
    }
  }
  onSubmit(){
    let body:any={
      userName:this.userName,
      password:this.password
    }
    this.ss.adminlogin(body).subscribe((admtok)=>{
      debugger
      console.log(admtok);
      if(admtok=="invalid"){
        alert("Invalid username or password")


      }
      else{

        console.log(admtok);
        localStorage.setItem("adtoken",admtok);
        this.router.navigateByUrl('/updateproducts');
        console.log("adtoken ="+admtok);
      }
    })
  }

}
