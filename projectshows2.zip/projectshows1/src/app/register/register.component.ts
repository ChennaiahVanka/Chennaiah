import { Component, OnInit } from '@angular/core';
import { ShoeService } from '../shoe.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor(private ss:ShoeService) { }
  
  name:any;
  email:any;
  password:any;
  phone:any;
  city:any
  
  get isEmailValid(): boolean {
    return this.email.endsWith('@gmail.com');
  }
  get isFormValid(): boolean {
    return this.name && this.email && this.password && this.phone && this.city && this.isEmailValid;
  }
  



submitform(){
  debugger
  let body={
    name:this.name,
    email:this.email,
    password:this.password,
    phone:this.phone,
    city:this.city
  }
  this.ss.postuser(body).subscribe(
    (data)=>{
      console.log(body)
      console.log(data)
      alert("Registered Successfully")
    },
    (error)=>{
      alert("Email already exists")
    }
  )
  this.clearform()
}
clearform(){
  this.name="",
  this.email="",
  this.password="",
  this.phone="",
  this.city=""
  
}

  ngOnInit(): void {
  }

}
