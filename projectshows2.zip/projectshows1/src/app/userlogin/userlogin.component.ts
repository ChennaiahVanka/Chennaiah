import { Component, OnInit } from '@angular/core';
import { ShoeService } from '../shoe.service';
import { Route, Router } from '@angular/router';
import { NgForm } from '@angular/forms';
@Component({
  selector: 'app-userlogin',
  templateUrl: './userlogin.component.html',
  styleUrls: ['./userlogin.component.css']
})
export class UserloginComponent implements OnInit {
  
  email=''
  password=''
  // constructor(private ss:ShoeService, private router:Router) { }
  constructor(private router:Router) { }

  ngOnInit(): void {
    if(localStorage.getItem('token')!="invaild"){
      this.router.navigateByUrl('/products');
    }

  }
  cool:any="";
  onSubmit(){
    debugger
    let body:any={
        email:this.email,
        Password:this.password
    }
      this.ss.userlogin(body).subscribe((moblog:any)=>{
          console.log(moblog)
          if(moblog!="invaild"){
        
              localStorage.setItem("token",moblog);
              this.router.navigateByUrl('/products');
            // console.log("Token ="+moblog);
            
          }
          else{
            alert("login username or password mismatch");
          }
      }
      )
      this.ss.getdata(body).subscribe((data:any)=>{
        //console.log(data);
        this.cool=data;
        //console.log(this.cool.name);
        console.log(this.cool.id)
        localStorage.setItem("userid",this.cool.id)
        
      })
  }

}
