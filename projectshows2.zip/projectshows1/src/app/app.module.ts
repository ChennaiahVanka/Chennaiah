import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import{HttpClientModule} from '@angular/common/http';

import { AuthadminGuard } from './Auth/authadmin.guard';
import { AppComponent } from './app.component';
import { AuthGuard } from './Auth/auth.guard';
//import { ShoeService } from './shoe.service';
import { WorkComponent } from './work/work.component';
import { FormsModule,ReactiveFormsModule} from '@angular/forms';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { AddtocartComponent } from './addtocart/addtocart.component';
import { RegisterComponent } from './register/register.component';
import { HeaderComponent } from './header/header.component';
import { HomeComponent } from './home/home.component';
import { OrderdetailsComponent } from './orderdetails/orderdetails.component';
import { ProductsComponent } from './products/products.component';
import { UpdateproductsComponent } from './updateproducts/updateproducts.component';
import { UserloginComponent } from './userlogin/userlogin.component';
import { UserorderdetailsComponent } from './userorderdetails/userorderdetails.component';
import { Route,RouterModule,Routes } from '@angular/router';
import { UserdetailsComponent } from './userdetails/userdetails.component';
import { CartitemsComponent } from './cartitems/cartitems.component';




const routes:Routes=[
  {
      path:'',component:HomeComponent
  },
  {
      path:'home',component:HomeComponent
  },
  {
      path:'userlogin',component:UserloginComponent
  },
  {
      path:'adminlogin',component:AdminloginComponent
  },
  {
    path:'addtocart',component:AddtocartComponent
  },
  {
      path:'register',component:RegisterComponent
  },
  {
      path:'products',component:ProductsComponent,canActivate:[AuthGuard]
  },
  {
      path:'updateproducts',component:UpdateproductsComponent,canActivate:[AuthadminGuard]
  },
  {
      path:'orderdetails',component:OrderdetailsComponent
  },
  {
    path:'userorderdetails',component:UserorderdetailsComponent
  },
  {
    path:'userdetails',component:UserdetailsComponent
  },
  {
    path:'cartitems',component:CartitemsComponent
  },

 
]



@NgModule({
  declarations: [
    AppComponent,
    WorkComponent,
    AdminloginComponent,
    AddtocartComponent,
    RegisterComponent,
    HeaderComponent,
    HomeComponent,
    OrderdetailsComponent,
    ProductsComponent,
    UpdateproductsComponent,
    UserloginComponent,
    UserorderdetailsComponent,
    UserdetailsComponent,
    CartitemsComponent
 
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forRoot(routes),
    

  ],
  // providers: [ShoeService],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
