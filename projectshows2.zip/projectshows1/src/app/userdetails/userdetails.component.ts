import { Component, OnInit } from '@angular/core';
import { ShoeService } from '../shoe.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-userdetails',
  templateUrl: './userdetails.component.html',
  styleUrls: ['./userdetails.component.css']
})
export class UserdetailsComponent implements OnInit {
  hello:any="";

  constructor(private ss:ShoeService,private route:Router ) { }

  ngOnInit(): void {
    this.ss.getusersdata().subscribe((data)=>{
      this.hello=data;
    })
  }
  Back(){
    this.route.navigate(['/orderdetails'])
  }

}
