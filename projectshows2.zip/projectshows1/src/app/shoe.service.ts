// import { HttpClient, HttpHeaders } from '@angular/common/http';
// import { Injectable } from '@angular/core';
// import { map, Observable } from 'rxjs';


// @Injectable({
//   providedIn: 'root'
// })
// export class ShoeService {

//   constructor(private http:HttpClient) { }

//   // userurl="https://localhost:7148/api/User"
//   // url="https://localhost:7148/api/Products"


//   postuser(body:any)
//   {
//     return this.http.post(this.userurl+"/Register",body, {responseType:'text'})
//   }
//   userlogin(body:any){
//     return this.http.post(this.userurl+"/Login",body,{responseType:'text'})
//   }
//   adminlogin(body:any){
//     return this.http.post(this.url+"/Login",body,{responseType:'text'})
//   }
//   getproduct(){
//     const token = localStorage.getItem('token');
//     console.log(token);
//     var header=new HttpHeaders({'Authorization' : `Bearer ${token}` })
//     return this.http.get(this.userurl+"/GetProduct",{headers:header});
//   }
//   additemtocart(body:any){
//     return this.http.post(this.userurl+"/additems",body)
//   }
//   getdata(body:any){
//     return this.http.post(this.userurl+"/getdata",body)
//   }
//   getusersdata(){
//     return this.http.get(this.userurl+"/getuserdetails")
//   }
//   deletecart(userid:any){
//     return this.http.delete(this.userurl+"/deletecart,"+userid,{responseType:'text'})
//   }
//   addorder(ordersToAdd:any){
//     return this.http.post(this.userurl+"/addnewitem",ordersToAdd)
//   }
//   getitems(userid: any): Observable<any[]> {
//     return this.http.get(this.userurl+"/GetCartitems,"+userid).pipe(
//       map((response: any) => {
//         return Array.isArray(response) ? response : [response];
//       })
//     );
//   }
//   getuserorderdetails(userid:any){
//     return this.http.get(this.url+"/Getorderdetailsbyuserid?userid="+userid)
//   }
//   getorderdetails(){
//     return this.http.get(this.url+"/GetOrderdetails")
//   }
//   getcategory(){
//     return this.http.get(this.userurl+"/Getcategory")
//   }
//   fetchshoes(){
//     const adtoken = localStorage.getItem('adtoken');
//     console.log(adtoken);
//     var header=new HttpHeaders({'Authorization' : `Bearer ${adtoken}` })
//     return this.http.get('https://localhost:7148/api/Products/GetProduct',{headers:header})
//   }
//   deleteshoe(id:any){
//     return this.http.delete('https://localhost:7148/api/Products/'+id)
//   }
//   postshoe(body:any){
//     return this.http.post(this.url+"/addproducts",body)
//   }

//   putshoe(body:any,id:any){
//     return this.http.put("https://localhost:7148/api/Products/UpdateProducts/"+id,body)
//   }
//   postorder(body:any){
//     return this.http.post(this.url+"/addOrder",body)
//   }

 

// }
