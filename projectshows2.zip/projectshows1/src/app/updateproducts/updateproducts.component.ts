import { Component, OnInit } from '@angular/core';
import { ShoeService } from '../shoe.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-updateproducts',
  templateUrl: './updateproducts.component.html',
  styleUrls: ['./updateproducts.component.css']
})
export class UpdateproductsComponent implements OnInit {

  constructor(private ss:ShoeService,private router:Router) { }
  formHeader="Add Shoes";
  showForm=false;
  productType:string="";
  shoes:any=null;
  price:any;
  categoryId:any;

  id=null;
  imageurl:any;
  Category:any=null;
  showcat=false;

  openForm(data:any=null){
    this.clearForm();
    this.showForm=true;
    
    
    if(data){
      this.productType=data.productType;
      this.price=data.price;
      this.categoryId=data.categoryId;
      this.imageurl=data.imageurl;

      this.formHeader="Edit Products"
      this.id=data.id;
   
    }
    else{
      this.id=null;
      this.formHeader="Add Products"
    }

  }
  

  closeForm(){
    this.clearForm()
    this.showForm=false
  }
  clearForm(){
    this.productType="";
    this.price="";;
    this.categoryId="";
    this.imageurl="";
  }

  saveshoe(){
    this.showForm=false;
    
    if(this.id!=null){
      let body={
        productType:this.productType,
        price:this.price,
        categoryId:this.categoryId,
        imageurl:this.imageurl,
        id:this.id
      }
      this.ss.putshoe(body,this.id).subscribe((data)=>{
        this.getshoes()
        alert("edited successfully")
      })      
    }
    else{
      let body={
        productType:this.productType,
        price:this.price,
        categoryId:this.categoryId,
        imageurl:this.imageurl
        
      }
    this.ss.postshoe(body).subscribe((data)=>{
      this.getshoes()
      alert("Shoe added successfully")
    })
  }
    
  }


  ngOnInit(): void {
    this.getshoes()

  }
  getshoes(){
    this.ss.fetchshoes().subscribe((data=>{
      this.shoes=data
    }))
  }

  deleteshoe(id:any){
    this.ss.deleteshoe(id).subscribe((res)=>{
        this.getshoes()
        alert("Shoe deleted successfully")

    })
  }
  opencategory(){
      this.showcat=true;
      this.ss.getcategory().subscribe((cool)=>{
      this.Category=cool;
    })
  }
  closecat(){
    this.showcat=false;
  }

  openorderdetails(){
    this.router.navigate(['/orderdetails'])
  }
  onlogout(){
    localStorage.removeItem("adtoken");
    this.router.navigate(['/adminlogin']);
  }

}
