import { Component, OnInit } from '@angular/core';
import { ShoeService } from '../shoe.service';
import { Router } from '@angular/router';
import { observable } from 'rxjs';

@Component({
  selector: 'app-cartitems',
  templateUrl: './cartitems.component.html',
  styleUrls: ['./cartitems.component.css']
})
export class CartitemsComponent implements OnInit {

  constructor(private ss:ShoeService,private route:Router) { }
  carts:any;
  data:any;
  userid=localStorage.getItem("userid");
  ngOnInit(): void {
    console.log(this.userid);
    
    this.ss.getitems(this.userid).subscribe((data)=>{
     
      this.carts=data;
    })
  }
  onclick(){
    this.ss.deletecart(this.userid).subscribe((data)=>{

    })
    this.route.navigate(['/products'])
  }
  click(){
    this.route.navigate(['/products'])
  }
  buynowbtn(){
    
    this.ss.getitems(this.userid).subscribe((data)=>{
      console.log(data)
      const ordersToAdd = data.map(item => {
        const { id, ...rest } = item;
        return rest;
      });
      console.log(ordersToAdd)
      this.ss.addorder(ordersToAdd).subscribe(()=>{
          alert("order placed successfully")
      })
    })
    this.ss.deletecart(this.userid).subscribe((data)=>{

    })
    this.route.navigate(['/products'])
  }

}
