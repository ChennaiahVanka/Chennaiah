import { Component, OnInit } from '@angular/core';
// import { ShoeService } from '../shoe.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-orderdetails',
  templateUrl: './orderdetails.component.html',
  styleUrls: ['./orderdetails.component.css']
})
export class OrderdetailsComponent implements OnInit {
  orders:any=null;


  constructor(private router:Router) { }
  // private ss:ShoeService,

  ngOnInit(): void {
    this.ss.getorderdetails().subscribe((data)=>{
      this.orders=data;
  })
  }
  Back(){
    this.router.navigate(['/updateproducts'])
  }
  usersdata(){
    this.router.navigate(['/userdetails'])
  }

}
