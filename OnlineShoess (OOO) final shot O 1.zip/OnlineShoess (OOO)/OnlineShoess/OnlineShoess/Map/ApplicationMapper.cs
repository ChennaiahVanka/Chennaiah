﻿using AutoMapper;
using OnlineShoess.DTO.Admin;
using OnlineShoess.DTO.User;
using OnlineShoess.Models;

namespace OnlineShoess.Map
{
    public class ApplicationMapper:Profile
    {
        public ApplicationMapper()
        {
            CreateMap<User, UserRegisterDto>().ReverseMap();
            CreateMap<User, UserLoginDto>().ReverseMap();
            CreateMap<Admin, AdminUserDto>().ReverseMap();
        }
    }
}
