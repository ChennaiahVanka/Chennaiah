﻿using OnlineShoess.DTO.User;
using OnlineShoess.Models;
using System;
using System.Collections.Generic;

namespace OnlineShoess.Repository
{
    public interface IUserRepository
    {

        User GetById(int id);
        UserRegisterDto Register(UserRegisterDto userRegisterDto);
        IEnumerable<Category> GetCategory();
        String Update(int Id, User user);
        string Login(UserLoginDto userLoginDto);

        IEnumerable<Product> GetProdusts();
        List<Product> GetProductByCategoryId(int CategoryId);

        User getUser(UserLoginDto userLoginDto);

        void additems(Cartitems cartitems);

        IEnumerable<Cartitems> getCartitems(int userid);

        void deletecart(int userid);

        void addneworder(IEnumerable<Orderdetails> orderdetails);

        IEnumerable<User> getuserdetails();

    }
}
