﻿using OnlineShoess.DTO.Admin;
using OnlineShoess.Models;
using System;
using System.Collections.Generic;

namespace OnlineShoess.Repository
{
    public interface IProductRepository
    {
        IEnumerable<Product> GetAll();
        IEnumerable<User> GetUsers();
        Product GetById(int id);
        void AddProducts(Product product);
        Product UpdateProducts(int Id, Product product);
        string Login(AdminUserDto adminUserDto);
        Product DeleteProducts(int Id);

        IEnumerable<Orderdetails> GetOrderDetails();

        List<Orderdetails> getorderdetailsbyid(int userid);

        void AddOrder(Orderdetails orderdetails);
        IEnumerable<Product> GetProdusts();
        void AddCategory(Category category);

    }
}
