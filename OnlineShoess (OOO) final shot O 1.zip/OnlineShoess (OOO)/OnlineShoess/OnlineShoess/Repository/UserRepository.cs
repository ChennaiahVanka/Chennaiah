﻿using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using OnlineShoess.Data;
using OnlineShoess.Models;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System;
using System.Linq;
using OnlineShoess.DTO.User;
using Microsoft.EntityFrameworkCore;
using AutoMapper;

namespace OnlineShoess.Repository
{
    public class UserRepository : IUserRepository
    {
        private readonly IConfiguration _config;
        private readonly IMapper _mapper;
        public UserRepository(IConfiguration config,IMapper mapper)
        {
            _config = config;
            _mapper= mapper;
        }
        AppDbContext _dbContext = new AppDbContext();
     

 

        public String Update(int Id, User user)
        {
            User newone = _dbContext.Users.FirstOrDefault(u => u.Id == user.Id);
            if (newone == null)
            {
                return ("Not Found");
            }
            else
            {
                newone.Name = user.Name;
                newone.Email = user.Email;
                newone.Password = user.Password;
                newone.Phone = user.Phone;
                newone.City = user.City;
                _dbContext.SaveChanges();
                return ("successfully updated");
            }
        }


        public IEnumerable<Product> GetProdusts()
        {
            var data = _dbContext.Products;
            return data;
        }

        public IEnumerable<Category> GetCategory()
        {
            var category = _dbContext.Categories;
            return category;

        }

        public List<Product> GetProductByCategoryId(int CategoryId)
        {
            var hello = _dbContext.Products.Where(u => u.CategoryId == CategoryId);
      
            return hello.ToList();
        }

        public UserRegisterDto Register(UserRegisterDto userRegisterDto)
        {
            var user = _mapper.Map<User>(userRegisterDto);
            var exist = _dbContext.Users.FirstOrDefault(u => u.Email == userRegisterDto.Email);
            if (exist != null)
            {
                return null;
            }

            _dbContext.Users.Add(user);
            _dbContext.SaveChanges();
            var registeredto = _mapper.Map<UserRegisterDto>(user);
            return registeredto;
        }

        public string Login(UserLoginDto userLoginDto)
        {
            var log = _dbContext.Users.FirstOrDefault(u => u.Email == userLoginDto.Email && u.Password == userLoginDto.Password);
            if (log == null)
            {
                return ("invaild");
            }
            else
            {
                var SecurityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["JWT:Key"]));
                var credential = new SigningCredentials(SecurityKey, SecurityAlgorithms.HmacSha256);
                var Claims = new[]
                {
                new Claim(ClaimTypes.Email,userLoginDto.Email)
            };
                var token = new JwtSecurityToken(
                    issuer: _config["JWT:Issuer"],
                    audience: _config["JWT:Audience"],
                    signingCredentials: credential,
                    claims: Claims,
                    expires: DateTime.Now.AddMinutes(1000));
                var Jwt = new JwtSecurityTokenHandler().WriteToken(token);
                return (Jwt);
            };

        }

        public User GetById(int id)
        {
            var userexist = _dbContext.Users.FirstOrDefault(x => x.Id == id);
            return userexist;
        }

        public User getUser(UserLoginDto userLoginDto)
        {
            var data = _dbContext.Users.FirstOrDefault(u => u.Email == userLoginDto.Email && u.Password == userLoginDto.Password);
            return data;
        }

        public void additems(Cartitems cartitems)
        {
            _dbContext.Cartitems.Add(cartitems);
            _dbContext.SaveChanges();
        }



        public void deletecart(int userid)
        {
            var dele= _dbContext.Cartitems.Where(od => od.UserId == userid);
            if (dele != null)
            { 
                _dbContext.Cartitems.RemoveRange(dele);
                _dbContext.SaveChanges();
            }
        }

        public void addneworder(IEnumerable<Orderdetails> orderdetails)
        {
            var orders=new List<Orderdetails>();
            foreach (var orderdetail in orderdetails) 
            {
                orders.Add(orderdetail);
            }
            _dbContext.OrderDetails.AddRange(orders);
            _dbContext.SaveChanges();
        }

        public IEnumerable<User> getuserdetails()
        {
            var srh = _dbContext.Users;
            return srh;

        }

        public IEnumerable<Cartitems> getCartitems(int userid)
        {
            var hello = _dbContext.Cartitems.Where(cd => cd.UserId == userid);
            return hello;
        }
    }
}
