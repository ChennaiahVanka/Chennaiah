﻿using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using OnlineShoess.Data;
using OnlineShoess.Models;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System;
using System.Linq;
using OnlineShoess.DTO.Admin;

namespace OnlineShoess.Repository
{
    public class ProductRepository : IProductRepository
    {
        private readonly IConfiguration _config;
        public ProductRepository(IConfiguration config)
        {
            _config = config;
        }
        AppDbContext _dbContext = new AppDbContext();
        public void AddProducts(Product product)
        {
            _dbContext.Products.Add(product);
            _dbContext.SaveChanges();

        }

        public IEnumerable<Product> GetAll()
        {
            var productdata = _dbContext.Products;
            return productdata;
        }

        public Product GetById(int id)
        {
            var Productexist = _dbContext.Products.FirstOrDefault(x => x.Id == id);
            return Productexist;
        }

 

        public Product UpdateProducts(int Id, Product product)
        {
            var hello = _dbContext.Products.Find(Id);
            if (hello == null)
            {
                return null;
            }
            hello.ProductType = product.ProductType;
            hello.Price = product.Price;
            hello.CategoryId = product.CategoryId;
            hello.Imageurl = product.Imageurl;

            _dbContext.SaveChanges();
            return hello;
        }

        public Product DeleteProducts(int Id)
        {

            var del = _dbContext.Products.Find(Id);
            if (del == null)
            {
                return (null);
            }
            _dbContext.Products.Remove(del);
            _dbContext.SaveChanges();
            return (del);

        }

        public IEnumerable<User> GetUsers()
        {
            var hi = _dbContext.Users;
            return hi;
        }

        public string Login(AdminUserDto adminUserDto)
        {
            var adminexist = _dbContext.Admins.FirstOrDefault(u => u.UserName == adminUserDto.UserName && u.Password == adminUserDto.Password);
            if (adminexist != null)
            {
                var SecurityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["JWT:Key"]));
                var Credentials = new SigningCredentials(SecurityKey, SecurityAlgorithms.HmacSha256);
                var Claims = new[]
               {
                new Claim(ClaimTypes.Email,adminUserDto.UserName)
                };
                var token = new JwtSecurityToken(
                    issuer: _config["JWT:Issuer"],
                    audience: _config["JWT:Audience"],
                    claims: Claims,
                    expires: DateTime.Now.AddMinutes(60),
                    signingCredentials: Credentials);
                var JWT = new JwtSecurityTokenHandler().WriteToken(token);
                return JWT;
                
            }
            else
            {
                return ("invalid");
            }

        }

        public IEnumerable<Orderdetails> GetOrderDetails()
        {
            var data = _dbContext.OrderDetails;
            return data;
        }

        public List<Orderdetails> getorderdetailsbyid(int userid)
        {
            return _dbContext.OrderDetails.Where(od => od.UserId == userid).ToList();
        }

        public void AddOrder(Orderdetails orderdetails)
        {
            _dbContext.OrderDetails.Add(orderdetails);
            _dbContext.SaveChanges();
        }

        public IEnumerable<Product> GetProdusts()
        {
            var data = _dbContext.Products;
            return data;
        }

        public void AddCategory(Category category)
        {
            _dbContext.Categories.Add(category);
            _dbContext.SaveChanges ();
        }
    }
}
