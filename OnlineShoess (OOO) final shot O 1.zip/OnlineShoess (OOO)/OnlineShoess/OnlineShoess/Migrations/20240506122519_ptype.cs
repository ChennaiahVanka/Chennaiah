﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace OnlineShoess.Migrations
{
    /// <inheritdoc />
    public partial class ptype : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "ShoeName",
                table: "OrderDetails",
                newName: "ProductType");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "ProductType",
                table: "OrderDetails",
                newName: "ShoeName");
        }
    }
}
