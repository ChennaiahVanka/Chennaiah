﻿namespace OnlineShoess.DTO.Admin
{
    public class AdminUserDto
    {
        public string UserName { get; set; }

        public string Password { get; set; }
    }
}
