﻿using System.ComponentModel.DataAnnotations;

namespace OnlineShoess.DTO.User
{
    public class UserRegisterDto
    {
        public string Name { get; set; }
        [EmailAddress]
        [Required]
        [RegularExpression(@"[a-z]+[0-9]*@[a-z]+.com", ErrorMessage = "Invalid Email Address")]
        public string Email { get; set; }
        [Required]
        public string Password { get; set; }
        [Required]
        [StringLength(10)]
        [RegularExpression(@"[0-9]*$", ErrorMessage = "Invalid Phone Number")]
        public string Phone { get; set; }
        [Required]
        public string City { get; set; }
    }
}
