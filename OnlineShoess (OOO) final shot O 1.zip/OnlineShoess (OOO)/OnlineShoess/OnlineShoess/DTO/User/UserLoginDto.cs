﻿using System.ComponentModel.DataAnnotations;

namespace OnlineShoess.DTO.User
{
    public class UserLoginDto
    {
        [EmailAddress]
        [RegularExpression(@"[a-z]+[0-9]*@[a-z]+.com", ErrorMessage = "Invalid Email Address")]
        public string Email { get; set; }
        public string Password { get; set; }
    }
}
