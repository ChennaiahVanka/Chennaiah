﻿using System.Text.Json.Serialization;

namespace OnlineShoess.Models
{
    public class Cartitems
    {
        public int Id { get; set; }
        public string productType { get; set; }
        public double price { get; set; }
        public int Quantity { get; set; }
        public int Size { get; set; }

        public string imageUrl { get; set; }

        public int UserId { get; set; }
        [JsonIgnore]
        public User? User { get; set; }





    }
}
