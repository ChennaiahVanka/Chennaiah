﻿using System;
using System.Text.Json.Serialization;

namespace OnlineShoess.Models
{
    public class Product
    {
        public int Id { get; set; }
        public string ProductType { get; set; }
        public decimal Price { get; set; }

        public string Imageurl { get; set; }
        public int CategoryId { get; set; }
        [JsonIgnore]
        public Category Category { get; set; }

    }
}
