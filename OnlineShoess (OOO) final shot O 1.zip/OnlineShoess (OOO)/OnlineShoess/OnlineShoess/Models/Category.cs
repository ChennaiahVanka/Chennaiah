﻿using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace OnlineShoess.Models
{
    public class Category
    {
        public int Id { get; set; }
        public string BrandName { get; set; }

        [JsonIgnore]
        public List<Product> Products { get; set; }
    }
}
