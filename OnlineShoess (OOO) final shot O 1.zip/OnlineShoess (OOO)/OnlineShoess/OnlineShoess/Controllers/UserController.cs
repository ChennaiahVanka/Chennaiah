﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using OnlineShoess.DTO.User;
using OnlineShoess.Models;
using OnlineShoess.Repository;
using System.Collections.Generic;
using System.Linq;

namespace OnlineShoess.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserRepository _UserRepository;
        public UserController(IUserRepository userRepository)
        {
            _UserRepository = userRepository;
        }

        

        [HttpPost("[action]")]
        public IActionResult Register([FromBody] UserRegisterDto userRegisterDto)
        {
           var register =  _UserRepository.Register(userRegisterDto);
            if (register == null)
            {
                return BadRequest("Email already Exists");
            }
            return Ok("Registered");
            
        }
        [HttpPost("[action]")]
        public IActionResult Login([FromBody] UserLoginDto userLoginDto)
        {
            var bye = _UserRepository.Login(userLoginDto);
            return Ok(bye);
        }
        [HttpPut("{id}")]
        public void Update(int id, [FromBody] User user)
        {
            _UserRepository.Update(id, user);
        }

        [HttpGet("[action]")]

        [Authorize]

        public IActionResult GetProduct()
        {
            var log = _UserRepository.GetProdusts();
            return Ok(log);
        }
        [HttpGet("[action]")]
        public IActionResult Getcategory()
        {
            var category = _UserRepository.GetCategory();
            return Ok(category);
        }
        [HttpGet("[action]/{CategoryId}")]
//[Authorize]
        public IActionResult GetProductByCategoryId(int CategoryId)
        {
            var cat = _UserRepository.GetProductByCategoryId(CategoryId);
            if (cat == null)
            {
                return NotFound("Incorrect");
            }
            return Ok(cat);
        }
        [HttpPost("[action]")]

        public IActionResult getdata(UserLoginDto userLoginDto)
        {
            var bye = _UserRepository.getUser(userLoginDto);
            return Ok(bye);
        }
        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            var hi = _UserRepository.GetById(id);
            return Ok(hi);
        }
        [HttpPost("[action]")]

        public void additems([FromBody] Cartitems cartitems) 
        {
            _UserRepository.additems(cartitems);
        }
        [HttpGet("[action],{userid}")]
        public List<Cartitems> GetCartitems(int userid)
        {
            var hello=_UserRepository.getCartitems(userid);
            return hello.ToList();
        }
        [HttpDelete("[action],{userid}")]

        public void deletecart(int userid)
        { 
            _UserRepository.deletecart(userid); 
        }

        [HttpPost("[action]")]

        public IActionResult addnewitem(IEnumerable<Orderdetails> orderdetails)
        { 
            _UserRepository.addneworder(orderdetails);
            return Ok();
        }
        [HttpGet("[action]")]
        public List<User> getuserdetails()
        { 
            var rr=_UserRepository.getuserdetails(); 
            return rr.ToList();
        }

    }
}
