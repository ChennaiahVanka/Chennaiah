﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration.EnvironmentVariables;
using OnlineShoess.DTO.Admin;
using OnlineShoess.Models;
using OnlineShoess.Repository;
using System.Collections.Generic;
using System.Linq;

namespace OnlineShoess.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private readonly IProductRepository _productRepository;
        public ProductsController(IProductRepository productRepository)
        {
            _productRepository = productRepository;
        }
        [HttpGet("[action]")]
        public IActionResult GetUsers() 
        {
            var hi = _productRepository.GetUsers();
            return Ok(hi);
        }
        [HttpGet("[action]")]
        public IActionResult GetProducts()
        {
            var log = _productRepository.GetAll();
            return Ok(log);
        }

        [HttpPost("[action]")]
        public IActionResult Login([FromBody] AdminUserDto adminUserDto)
        {
            var log = _productRepository.Login(adminUserDto);
            return Ok(log);
        }

        [HttpPost("[action]")]
        public void addproducts([FromBody] Product product)
        {
            _productRepository.AddProducts(product);
        }

        [HttpPut("[action]/{Id}")]
        public void UpdateProducts(int Id, [FromBody] Product product)
        {
            _productRepository.UpdateProducts(Id, product);
        }

        [HttpDelete("{Id}")]
        public void DeleteProduct(int Id)
        {
            _productRepository.DeleteProducts(Id);


        }


        [HttpGet("[action]")]
        public List<Orderdetails> GetOrderdetails()
        {
            var srh = _productRepository.GetOrderDetails();
            return srh.ToList();
        }

        [HttpGet("[action]")]
        public List<Orderdetails> Getorderdetailsbyuserid(int userid)
        {
            var srh = _productRepository.getorderdetailsbyid(userid);
            return srh.ToList();
        }

        [HttpPost("[action]")]

        public IActionResult addOrder([FromBody] Orderdetails orderdetails)
        {
            _productRepository.AddOrder(orderdetails);
            return Ok();
        }


        [HttpGet("[action]")]
        [Authorize]
        public List<Product> GetProduct()
        {
            var log = _productRepository.GetProdusts();
            return log.ToList();
        }
        [HttpPost("[action]")]
        public void addcategory ([FromBody] Category category)
        {
            _productRepository.AddCategory(category);
        }
    }
}
